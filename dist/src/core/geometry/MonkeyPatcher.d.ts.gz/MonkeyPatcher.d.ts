import { InterleavedBufferAttribute } from 'three/src/core/InterleavedBufferAttribute';
export declare class MonkeyPatcher {
    static patch(attribute: InterleavedBufferAttribute): void;
}
