import { BufferGeometry } from 'three/src/core/BufferGeometry';
export declare class CoreGeometryBuilderMerge {
    static merge(geometries: BufferGeometry[]): BufferGeometry | undefined;
}
