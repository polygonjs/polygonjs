export declare class CoreDom {
    static add_drag_classes(): void;
    static remove_drag_classes(): void;
    static set_cursor_col_resize(): void;
    static unset_cursor_col_resize(): void;
}
