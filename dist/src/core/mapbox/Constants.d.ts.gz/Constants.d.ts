export declare const CoreMapboxConstants: {
    WORLD_SIZE: number;
    PROJECTION_WORLD_SIZE: number;
    MERCATOR_A: number;
    DEG2RAD: number;
    RAD2DEG: number;
    EARTH_CIRCUMFERENCE: number;
};
