export declare enum SceneEvent {
    FRAME_RANGE_UPDATED = "scene_frame_range_updated",
    FRAME_UPDATED = "scene_frame_updated",
    PLAY_STATE_UPDATED = "scene_play_state_updated"
}
