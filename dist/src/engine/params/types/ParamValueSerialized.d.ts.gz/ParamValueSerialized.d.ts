import { ParamValueSerializedTypeMap } from './ParamValueSerializedTypeMap';
export declare type ParamValueSerialized = ParamValueSerializedTypeMap[keyof ParamValueSerializedTypeMap];
