import { ParamValuesTypeMap } from './ParamValuesTypeMap';
export declare type ParamValue = ParamValuesTypeMap[keyof ParamValuesTypeMap];
