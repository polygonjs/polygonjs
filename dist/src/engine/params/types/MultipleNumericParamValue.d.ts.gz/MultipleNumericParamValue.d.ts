import { Vector2 } from 'three/src/math/Vector2';
import { Vector3 } from 'three/src/math/Vector3';
import { Vector4 } from 'three/src/math/Vector4';
import { Color } from 'three/src/math/Color';
export declare type MultipleNumericParamValue = Vector2 | Vector3 | Vector4 | Color;
