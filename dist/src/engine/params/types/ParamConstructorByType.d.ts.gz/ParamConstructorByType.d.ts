import { ParamType } from '../../poly/ParamType';
declare type ParamClassMapType = {
    [key in ParamType]: any;
};
export declare const ParamConstructorByType: ParamClassMapType;
export {};
