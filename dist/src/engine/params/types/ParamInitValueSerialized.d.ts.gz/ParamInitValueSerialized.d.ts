import { ParamInitValueSerializedTypeMap } from './ParamInitValueSerializedTypeMap';
export declare type ParamInitValueSerialized = ParamInitValueSerializedTypeMap[keyof ParamInitValueSerializedTypeMap];
