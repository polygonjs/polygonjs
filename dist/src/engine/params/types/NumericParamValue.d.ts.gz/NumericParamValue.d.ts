import { MultipleNumericParamValue } from './MultipleNumericParamValue';
export declare type NumericParamValue = MultipleNumericParamValue | number;
