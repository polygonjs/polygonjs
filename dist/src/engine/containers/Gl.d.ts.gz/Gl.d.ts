import { TypedContainer } from './_Base';
import { ContainableMap } from './utils/ContainableMap';
export declare class GlContainer extends TypedContainer<ContainableMap['GL']> {
    object(): string;
}
