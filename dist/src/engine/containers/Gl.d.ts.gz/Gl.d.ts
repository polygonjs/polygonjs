import { TypedContainer } from './_Base';
import { NodeContext } from '../poly/NodeContext';
export declare class GlContainer extends TypedContainer<NodeContext.GL> {
    object(): string;
}
