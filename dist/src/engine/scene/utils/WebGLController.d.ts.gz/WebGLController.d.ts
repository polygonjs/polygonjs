export declare class WebGLController {
    constructor();
    _require_webgl2: boolean;
    require_webgl2(): boolean;
    set_require_webgl2(): void;
}
