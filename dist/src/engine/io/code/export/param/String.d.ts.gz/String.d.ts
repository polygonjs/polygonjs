import { ParamCodeExporter } from '../Param';
import { StringParam } from '../../../../params/String';
export declare class ParamStringCodeExporter extends ParamCodeExporter<StringParam> {
    as_code_default_value_string(): string;
    add_main(): void;
}
