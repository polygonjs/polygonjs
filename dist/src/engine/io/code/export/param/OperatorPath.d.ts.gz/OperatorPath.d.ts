import { ParamCodeExporter } from '../Param';
import { OperatorPathParam } from '../../../../params/OperatorPath';
export declare class ParamOperatorPathCodeExporter extends ParamCodeExporter<OperatorPathParam> {
    as_code_default_value_string(): string;
    add_main(): void;
}
