import { ParamJsonExporter } from '../Param';
import { OperatorPathParam } from '../../../../params/OperatorPath';
export declare class ParamOperatorPathJsonExporter extends ParamJsonExporter<OperatorPathParam> {
    add_main(): string | undefined;
}
