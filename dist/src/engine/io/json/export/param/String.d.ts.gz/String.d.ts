import { ParamJsonExporter } from '../Param';
import { StringParam } from '../../../../params/String';
export declare class ParamStringJsonExporter extends ParamJsonExporter<StringParam> {
    add_main(): string | undefined;
}
