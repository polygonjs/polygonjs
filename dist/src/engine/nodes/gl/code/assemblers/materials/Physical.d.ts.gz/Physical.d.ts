import { ShaderAssemblerStandard } from './Standard';
export declare class ShaderAssemblerPhysical extends ShaderAssemblerStandard {
    is_physical(): boolean;
}
