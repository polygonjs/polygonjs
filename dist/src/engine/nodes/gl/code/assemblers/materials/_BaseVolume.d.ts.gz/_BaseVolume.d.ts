import { ShaderAssemblerMaterial, CustomAssemblerMap } from './_BaseMaterial';
export declare abstract class BaseShaderAssemblerVolume extends ShaderAssemblerMaterial {
    custom_assembler_class_by_custom_name(): CustomAssemblerMap;
}
