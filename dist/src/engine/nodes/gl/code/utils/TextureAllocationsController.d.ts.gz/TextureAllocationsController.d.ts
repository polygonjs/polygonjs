import { TextureAllocation } from './TextureAllocation';
import { BaseGlNodeType } from '../../_Base';
import { TextureVariable, TextureVariableData } from './TextureVariable';
import { ShaderConfig } from '../configs/ShaderConfig';
import { ShaderName } from '../../../utils/shaders/ShaderName';
import { PolyScene } from '../../../../scene/PolyScene';
export declare type TextureAllocationsControllerData = Dictionary<TextureVariableData[] | undefined>[];
export declare class TextureAllocationsController {
    private _allocations;
    private _next_allocation_index;
    constructor();
    allocate_connections_from_root_nodes(root_nodes: BaseGlNodeType[], leaf_nodes: BaseGlNodeType[]): void;
    allocate_variables(variables: TextureVariable[]): void;
    allocate_variable(new_variable: TextureVariable): void;
    next_allocation_name(): ShaderName;
    shader_names(): ShaderName[];
    create_shader_configs(): ShaderConfig[];
    allocation_for_shader_name(shader_name: ShaderName): TextureAllocation;
    input_names_for_shader_name(root_node: BaseGlNodeType, shader_name: ShaderName): string[] | undefined;
    variable(variable_name: string): TextureVariable | undefined;
    variables(): TextureVariable[];
    has_variable(name: string): boolean;
    to_json(scene: PolyScene): TextureAllocationsControllerData;
    print(scene: PolyScene): void;
}
