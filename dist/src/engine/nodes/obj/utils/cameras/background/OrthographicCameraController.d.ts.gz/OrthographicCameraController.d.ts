import { BaseBackgroundController } from './_BaseController';
export declare class OrthographicCameraBackgroundController extends BaseBackgroundController {
    protected update_screen_quad(): void;
}
