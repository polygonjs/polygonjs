import { BaseNodeType } from '../../_Base';
export declare class HierarchyParentController {
    protected node: BaseNodeType;
    private _parent;
    private _on_set_parent_hooks;
    constructor(node: BaseNodeType);
    get parent(): BaseNodeType | null;
    set_parent(parent: BaseNodeType | null): void;
    is_selected(): boolean;
    full_path(): string;
    on_set_parent(): void;
    find_node(path: string): BaseNodeType | null;
}
